import { Routes } from '@angular/router';

export const MAIN_LAYOUT_ROUTES: Routes = []
