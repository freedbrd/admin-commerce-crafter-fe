import {
  ActivatedRouteSnapshot,
  CanActivateFn, Router,
  RouterStateSnapshot,
} from '@angular/router';
import { inject } from '@angular/core';
import { Store } from '@ngrx/store';
import { selectSession } from '../ngrx/auth/auth.selectors';
import { of, switchMap } from 'rxjs';

export const authGuard: CanActivateFn = (
  route: ActivatedRouteSnapshot, state: RouterStateSnapshot
) => {
  const router = inject(Router)
  const store = inject(Store)

  return store.select(selectSession).pipe(
    switchMap(res => {
      return res ? of(!!res) : of(router.parseUrl('auth'))
    })
  )
}
