export const environment = {
  supabaseKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZ4bW5ienJ3Znp2b2tkdGVnZ3N4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3MDUxODczNzcsImV4cCI6MjAyMDc2MzM3N30.QhJo3vm_3q5g2gKblfyPo2XFvcP5jtRHORvont8mcAA',
  supabaseUrl: 'https://vxmnbzrwfzvokdteggsx.supabase.co'
}
